import {View, Text, StyleSheet, TouchableOpacity} from 'react-native'
import React, { useState } from 'react'

export default function App() {
  const [resultado, setResultado] = useState(0);

  const realizarSoma = () => {
    const n1 = 10;
    const n2 = 5;
    const somaTotal = n1 + n2;
    setResultado(somaTotal);
  }

  // Função para resetar o valor para zero
  const resetarSoma = () => {
    setResultado(0);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Somador automático</Text>

      <Text style={styles.numero}>Número A: 10</Text>
      <Text style={styles.numero}>Número B: 5</Text>

      <TouchableOpacity style={styles.botao} onPress={realizarSoma}>
         <Text style={styles.textoBotao}>SOMAR AGORA</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.botao, styles.botaoReset]} onPress={resetarSoma}>
         <Text style={styles.textoBotao}>LIMPAR</Text>
      </TouchableOpacity>

      <Text style={styles.resultadoFinal}>
        O resultado é: {resultado}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container : {
    flex: 1,
    backgroundColor: '#FFFFFF', 
    alignItems: 'center',
    justifyContent: 'center',
  },
  titulo : {
    fontSize: 24,
    fontWeight:'bold',
    marginBottom: 20,
    color: '#1A73E8',
  },
  numero : {
    fontSize: 18,
    marginVertical: 5, 
  },
  botao: {
    backgroundColor: '#1A73E8',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginTop: 20,
    width: 200,
    alignItems: 'center',
  },
  botaoReset: {
    backgroundColor: '#EA4335', 
    marginTop: 10,
  },
  textoBotao: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  resultadoFinal: {
    marginTop: 30,
    fontSize: 22,
    fontWeight: 'bold',
    color: '#34A853', 
  },
})
